
import React from 'react';

interface SliderProps {
  label: string;
  value: number;
  min: number;
  max: number;
  onChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
}

const Slider: React.FC<SliderProps> = ({ label, value, min, max, onChange }) => {
  return (
    <div className="space-y-3">
      <div className="flex justify-between items-center">
        <label htmlFor="length-slider" className="text-lg font-medium text-white">{label}</label>
        <span className="text-xl font-bold text-indigo-300 w-8 text-center">{value}</span>
      </div>
      <input 
        id="length-slider"
        type="range"
        min={min}
        max={max}
        value={value}
        onChange={onChange}
        className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
        style={{
          background: `linear-gradient(to right, #6366f1 0%, #6366f1 ${((value - min) / (max - min)) * 100}%, #4b5563 ${((value - min) / (max - min)) * 100}%, #4b5563 100%)`
        }}
      />
    </div>
  );
};

export default Slider;
