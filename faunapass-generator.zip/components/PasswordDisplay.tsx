
import React from 'react';
import Icon from './Icon';

interface PasswordDisplayProps {
  password?: string;
  onCopy: () => void;
  copied: boolean;
}

const PasswordDisplay: React.FC<PasswordDisplayProps> = ({ password, onCopy, copied }) => {
  return (
    <div className="relative flex items-center bg-black/30 rounded-lg p-4">
      <span className="flex-grow font-mono text-xl text-white tracking-wider truncate pr-12">
        {password || <span className="text-gray-400">Your password here...</span>}
      </span>
      <button 
        onClick={onCopy}
        className="absolute right-3 top-1/2 -translate-y-1/2 p-2 text-gray-300 hover:text-white transition-colors duration-200 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-400"
        aria-label="Copy password to clipboard"
      >
        {copied ? <Icon name="check" className="w-6 h-6 text-green-400" /> : <Icon name="copy" className="w-6 h-6" />}
      </button>
    </div>
  );
};

export default PasswordDisplay;
